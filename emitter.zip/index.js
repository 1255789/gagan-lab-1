const math = require("./math");
const myEmitter = require("./emitter");

const result = math.square(2);
console.log(`Square of 2 is: ${result}`);
myEmitter.emit("event");
